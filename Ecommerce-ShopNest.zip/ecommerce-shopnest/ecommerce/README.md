Saima Rind Full Stack Developer - Completing My Task 01


# 🛍️ ShopNest — Django E-Commerce Store

A full-featured e-commerce web application built with Django (Python) + HTML/CSS/JavaScript.

## Features

- **Product Listings** — Browse products with category filters and search
- **Product Detail Pages** — Full product info, related items, quantity selector
- **Shopping Cart** — Session-based cart with AJAX add/remove/update
- **User Auth** — Register, Login, Logout with profile management
- **Checkout** — Shipping form with order placement
- **Order History** — View all past orders with status tracking
- **Admin Panel** — Manage products, categories, users, orders at `/admin/`

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run migrations
python manage.py migrate

# Start server
python manage.py runserver
```

Or use the startup script:
```bash
bash run.sh
```

## Demo Accounts

| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | admin123 |
| User  | demo     | demo123  |

## Project Structure

```
ecommerce/
├── ecommerce/          # Django project config
│   ├── settings.py
│   └── urls.py
├── store/              # Main app
│   ├── models.py       # Category, Product, Order, OrderItem, UserProfile
│   ├── views.py        # All page & AJAX views
│   └── admin.py        # Admin config
├── templates/store/    # HTML templates
│   ├── base.html       # Navbar, footer, toasts
│   ├── home.html       # Product grid + hero
│   ├── product_detail.html
│   ├── cart.html
│   ├── checkout.html
│   ├── orders.html
│   ├── login.html
│   ├── register.html
│   └── profile.html
├── static/
│   ├── css/style.css   # Full CSS design system
│   └── js/main.js      # Cart JS + toast notifications
├── db.sqlite3          # SQLite database
└── requirements.txt
```

## Tech Stack

- **Backend:** Django 4.2+ (Python)
- **Frontend:** HTML5, CSS3 (custom design system), Vanilla JavaScript
- **Database:** SQLite (easily switchable to PostgreSQL)
- **Auth:** Django's built-in auth system
- **Cart:** Session-based (no login required to browse)
