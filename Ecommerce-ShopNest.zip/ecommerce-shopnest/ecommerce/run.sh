#!/bin/bash
# ShopNest E-Commerce Startup Script

echo "================================================"
echo "  ShopNest E-Commerce Store"
echo "================================================"

# Install dependencies
echo "[1/3] Installing dependencies..."
pip install django djangorestframework Pillow --break-system-packages -q

# Apply migrations
echo "[2/3] Setting up database..."
cd "$(dirname "$0")"
python manage.py migrate --run-syncdb -v 0

# Seed data (if needed)
python manage.py shell -c "
from store.models import Product
if Product.objects.count() == 0:
    print('Seeding demo data...')
    exec(open('seed.py').read())
else:
    print(f'Database has {Product.objects.count()} products.')
" 2>/dev/null || true

echo "[3/3] Starting server..."
echo ""
echo "  🛍️  ShopNest is running at:  http://127.0.0.1:8000"
echo ""
echo "  Admin panel:  http://127.0.0.1:8000/admin/"
echo "  Admin login:  admin / admin123"
echo ""
echo "  Demo account: demo / demo123"
echo "================================================"
echo ""

python manage.py runserver 0.0.0.0:8000
