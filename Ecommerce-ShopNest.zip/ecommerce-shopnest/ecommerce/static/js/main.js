// ─── CSRF helper ─────────────────────────────────────────────────────────────
function getCsrf() {
  return document.cookie.split(';')
    .map(c => c.trim())
    .find(c => c.startsWith('csrftoken='))
    ?.split('=')[1] || '';
}

// ─── Toast notifications ──────────────────────────────────────────────────────
function showToast(msg, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity .3s';
    setTimeout(() => toast.remove(), 350);
  }, 2800);
}

// ─── Add to cart ──────────────────────────────────────────────────────────────
function addToCart(productId, btn, qty = 1) {
  const originalText = btn ? btn.textContent : null;
  if (btn) { btn.textContent = '✓ Added'; btn.style.opacity = '.7'; }

  fetch('/cart/add/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCsrf()
    },
    body: JSON.stringify({ product_id: productId, qty: qty })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      // Update badge
      const badge = document.getElementById('cart-badge');
      if (badge) {
        badge.textContent = data.cart_count;
        badge.style.transform = 'scale(1.4)';
        setTimeout(() => badge.style.transform = 'scale(1)', 250);
      }
      showToast('🛒 Added to cart!');
    }
  })
  .catch(() => showToast('Something went wrong', 'error'))
  .finally(() => {
    if (btn) {
      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.opacity = '1';
      }, 1200);
    }
  });
}

// ─── Auto-dismiss messages ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const msgs = document.querySelectorAll('.msg');
  msgs.forEach(m => {
    setTimeout(() => {
      m.style.transition = 'opacity .4s';
      m.style.opacity = '0';
      setTimeout(() => m.remove(), 450);
    }, 4000);
  });
});
