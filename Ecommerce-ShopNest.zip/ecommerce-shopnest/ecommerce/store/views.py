from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
import json
from .models import Product, Category, Order, OrderItem, UserProfile

# ─── Cart helpers (session-based) ───────────────────────────────────────────

def get_cart(request):
    return request.session.get('cart', {})

def save_cart(request, cart):
    request.session['cart'] = cart
    request.session.modified = True

def cart_count(request):
    cart = get_cart(request)
    return sum(v['qty'] for v in cart.values())

# ─── Public pages ────────────────────────────────────────────────────────────

def home(request):
    categories = Category.objects.all()
    cat_slug = request.GET.get('category')
    q = request.GET.get('q', '')
    products = Product.objects.filter(is_active=True)
    if cat_slug:
        products = products.filter(category__slug=cat_slug)
    if q:
        products = products.filter(name__icontains=q)
    return render(request, 'store/home.html', {
        'products': products,
        'categories': categories,
        'selected': cat_slug,
        'q': q,
        'cart_count': cart_count(request),
    })

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk, is_active=True)
    related = Product.objects.filter(category=product.category, is_active=True).exclude(pk=pk)[:4]
    return render(request, 'store/product_detail.html', {
        'product': product,
        'related': related,
        'cart_count': cart_count(request),
    })

# ─── Cart ────────────────────────────────────────────────────────────────────

def cart_view(request):
    cart = get_cart(request)
    items = []
    total = 0
    for pid, data in cart.items():
        try:
            p = Product.objects.get(pk=int(pid))
            subtotal = p.price * data['qty']
            total += subtotal
            items.append({'product': p, 'qty': data['qty'], 'subtotal': subtotal})
        except Product.DoesNotExist:
            pass
    return render(request, 'store/cart.html', {
        'items': items, 'total': total, 'cart_count': cart_count(request)
    })

@require_POST
def add_to_cart(request):
    data = json.loads(request.body)
    pid = str(data.get('product_id'))
    qty = int(data.get('qty', 1))
    cart = get_cart(request)
    if pid in cart:
        cart[pid]['qty'] += qty
    else:
        cart[pid] = {'qty': qty}
    save_cart(request, cart)
    return JsonResponse({'success': True, 'cart_count': sum(v['qty'] for v in cart.values())})

@require_POST
def update_cart(request):
    data = json.loads(request.body)
    pid = str(data.get('product_id'))
    qty = int(data.get('qty', 1))
    cart = get_cart(request)
    if qty <= 0:
        cart.pop(pid, None)
    else:
        cart[pid] = {'qty': qty}
    save_cart(request, cart)
    total = 0
    for p_id, d in cart.items():
        try:
            total += float(Product.objects.get(pk=int(p_id)).price) * d['qty']
        except:
            pass
    return JsonResponse({'success': True, 'cart_count': sum(v['qty'] for v in cart.values()), 'total': total})

@require_POST
def remove_from_cart(request):
    data = json.loads(request.body)
    pid = str(data.get('product_id'))
    cart = get_cart(request)
    cart.pop(pid, None)
    save_cart(request, cart)
    return JsonResponse({'success': True, 'cart_count': sum(v['qty'] for v in cart.values())})

# ─── Checkout & Orders ───────────────────────────────────────────────────────

@login_required
def checkout(request):
    cart = get_cart(request)
    if not cart:
        return redirect('cart')
    items = []
    total = 0
    for pid, data in cart.items():
        try:
            p = Product.objects.get(pk=int(pid))
            subtotal = p.price * data['qty']
            total += subtotal
            items.append({'product': p, 'qty': data['qty'], 'subtotal': subtotal})
        except:
            pass

    if request.method == 'POST':
        address = request.POST.get('address', '')
        phone = request.POST.get('phone', '')
        if not address:
            messages.error(request, 'Please enter a shipping address.')
        else:
            order = Order.objects.create(
                user=request.user,
                shipping_address=address,
                phone=phone,
                total_amount=total,
                status='pending',
            )
            for item in items:
                OrderItem.objects.create(
                    order=order,
                    product=item['product'],
                    quantity=item['qty'],
                    price=item['product'].price,
                )
                # Reduce stock
                p = item['product']
                p.stock = max(0, p.stock - item['qty'])
                p.save()
            # Clear cart
            request.session['cart'] = {}
            request.session.modified = True
            messages.success(request, f'Order #{order.id} placed successfully!')
            return redirect('order_success', order_id=order.id)

    profile = getattr(request.user, 'profile', None)
    return render(request, 'store/checkout.html', {
        'items': items, 'total': total,
        'cart_count': 0,
        'profile': profile,
    })

@login_required
def order_success(request, order_id):
    order = get_object_or_404(Order, pk=order_id, user=request.user)
    return render(request, 'store/order_success.html', {'order': order, 'cart_count': 0})

@login_required
def my_orders(request):
    orders = request.user.orders.all().order_by('-created_at')
    return render(request, 'store/orders.html', {'orders': orders, 'cart_count': cart_count(request)})

# ─── Auth ────────────────────────────────────────────────────────────────────

def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        password2 = request.POST.get('password2', '')
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()

        if not username or not password:
            messages.error(request, 'Username and password are required.')
        elif password != password2:
            messages.error(request, 'Passwords do not match.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken.')
        else:
            user = User.objects.create_user(username=username, email=email, password=password,
                                            first_name=first_name, last_name=last_name)
            UserProfile.objects.create(user=user)
            login(request, user)
            messages.success(request, f'Welcome, {username}!')
            return redirect('home')
    return render(request, 'store/register.html', {'cart_count': 0})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            next_url = request.GET.get('next', 'home')
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'store/login.html', {'cart_count': 0})

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def profile_view(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        request.user.email = request.POST.get('email', '')
        request.user.save()
        profile.phone = request.POST.get('phone', '')
        profile.address = request.POST.get('address', '')
        profile.city = request.POST.get('city', '')
        profile.save()
        messages.success(request, 'Profile updated successfully!')
    return render(request, 'store/profile.html', {
        'profile': profile, 'cart_count': cart_count(request)
    })
